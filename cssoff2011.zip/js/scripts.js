$(function() {
  var countdown;

  //Smooth Scrolling
  //================
   $('nav a').click(function(e){
        var $that = $(this);
        $('html, body').stop().animate({
            scrollTop: $($that.attr('href')).offset().top
        }, 1000);

        e.preventDefault();
    });


  //Color Picker
  //============
  $colorPicker = $("#picker");
  $colorPicker.hide();

  $("#team_color").focus(function(){
    $colorPicker.toggle();
  });
  $("#team_color").blur(function(){
    $colorPicker.toggle();
  });

  $("#picker").farbtastic("#team_color");


  $("#gender").dropkick({width: 112}); //Selectbox Replacement

  $("input, textarea").placeholder(); //Placeholder Polyfill

  //Ostacle Chooser
  //===============
  var $Obstacle = $("#obstacle_container li");
  $Obstacle.click(function(e){
    e.preventDefault(); 
    $Obstacle.removeClass("selected");
    $(this).addClass("selected");
    var obstacleName = $(this).children().find('img').attr("src"); 
    obstacleName = obstacleName.substr(0, obstacleName.indexOf("_thumb"));
    $("#large_format_obstacle img").attr("src", obstacleName + ".jpg");
    obstacleName = obstacleName.substr(obstacleName.indexOf("/images/") + 8 );
    obstacleName = obstacleName.replace(/_/g," ");
    //obstacleName = obstacleName.split("_");
    if ( obstacleName.length > 14 ) {
      $("#large_format_obstacle h3").css({ "font-size" : "31px" });
    } else {
      $("#large_format_obstacle h3").css({ "font-size" : "40px" });
    }

    $("#large_format_obstacle h3").html(obstacleName);
    var auxTxt = ""; 
    switch (obstacleName) {
      case "the tank":
        auxTxt = "But not his big bro&apos; Dozer";
        break;
      case "sundae slide":
        auxTxt = "Something clever about cherries";
        break;
      case "human hamster wheel":
        auxTxt = "there are 25 species of hamster";
        break;
      case "down the hatch":
        auxTxt = "6ft Slide Covered In Gunk!";
        break;
      case "pick it":
        auxTxt = "You can pick your friends&hellip;"; 
        break;
      case "the wringer":
        auxTxt = "your whites have never been whiter";
        break;
    }

    $("#large_format_obstacle h4").html(auxTxt);
  });

  //Timer Stuff
  //=============
  $("fieldset").children().focus(function(){
    if (!countdown){
      countdown = setInterval(function(){
        var curTime = +$("#timer").html() - 1;
        $("#timer").html(curTime);
        if (!curTime) clearInterval(countdown);
      }, 1000);
    }
  });
});
